 //package nicolib.comment;
package nicolib.comment; 

 /**
  * 生放送のコメントとコメントの送信結果を受け取るためのインターフェース
  * @author hal
  *
  */
 public interface ChatTransceiverHandler extends ChatReceiverHandler {
                 
         /**
          * コメントの送信結果を受け取ったときに呼び出されます。
          * @param chatResult
          * @param originalText
          */
         public void receiveChatResult(ChatResult chatResult, String originalText);
 }