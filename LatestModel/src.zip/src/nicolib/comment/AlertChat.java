//package nicolib.comment;
 package nicolib.comment;
 /**
  * コメ鯖から送られてくるアラート情報を表現するクラス
  * @author hal
  *
  */
 public class AlertChat extends Chat {
         
         String liveId;
         String communityId;
 
         public String getLiveId(){
                 return liveId;
         }
         
         public String getCommunityId() {
                 return communityId;
         }
         
         AlertChat(Chat chat){
                 message = chat.message;
                 no = chat.no;
                 thread = chat.thread;
                 vpos = chat.vpos;
                 
                 String[] p = message.split(",");
                 liveId = "lv" + p[0];
                 communityId = p[1];
                 userId = p[2];
         }
                         
 }