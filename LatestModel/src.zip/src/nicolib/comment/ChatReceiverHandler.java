//package nicolib.comment;
 package nicolib.comment;
 /**
  * 生放送のコメントを受け取るためのインターフェース
  * @author hal
  *
  */
 public interface ChatReceiverHandler {
         
         /**
          * コメントサーバーからコメントを受け取ったときに呼び出されます。
          * @param chat
          * @param originalText
          */
         public void receiveChat(Chat chat, String originalText);
 }