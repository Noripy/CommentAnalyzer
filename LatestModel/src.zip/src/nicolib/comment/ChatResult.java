//package nicolib.comment;
package nicolib.comment; 

 /**
  * コメントの送信結果を表現するクラス
  * @author hal
  *
  */
 public class ChatResult {
         int no;
         int status;
         int thread;
         
         public int getNo() {
                 return no;
         }
         
         public int getStatus() {
                 return status;
         }
         
         public int getThread() {
                 return thread;
         }
 }