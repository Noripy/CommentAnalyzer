 //package nicolib.comment;
 package nicolib.comment;
 
 /**
  * コメントサーバーへの接続・切断状況の通知を受け取るためのインターフェース
  * @author hal
  *
  */
 public interface ConnectionHandler {
         
         /**
          * サーバーとの通信が開始された時に呼び出されます
          * @param thread
          * @param originalText
          */
         public void connectServer(ThreadHeader thread, String originalText);
         
         /**
          * サーバーとの通信が終了したときに呼び出されます
          */
         public void disconnectServer();
 }