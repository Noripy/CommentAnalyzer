//package nicolib.comment;
package nicolib.comment; 

 import java.util.Date;
 
 /**
  * コメントサーバー接続時に最初に受け取るデータ
  * @author hal
  *
  */
 public class ThreadHeader {
         int lastRes;
         int resultCode;
         int revision;
         Date serverTime;
         int thread;
         String ticket;
         
         public int getLastRes() {
                 return lastRes;
         }
         
         public int getResultCode() {
                 return resultCode;
         }
         
         public int getRevision() {
                 return revision;
         }
         
         public Date getServerTime() {
                 return serverTime;
         }
         
         public int getThread() {
                 return thread;
         }
         
         public String getTicket() {
                 return ticket;
         }
 }