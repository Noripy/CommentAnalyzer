 package nicolib.cookie;
 
 import nicolib.NicolibException;
 
 public class CookieGetException extends NicolibException {
 
         /**
          * 
          */
         private static final long serialVersionUID = -5478366478820764991L;
         
         public CookieGetException(){
                 super();
         }
         
         public CookieGetException(String message){
                 super(message); 
         }
         
         public CookieGetException(String message, Throwable cause){
                 super(message, cause);
         }
 
 }