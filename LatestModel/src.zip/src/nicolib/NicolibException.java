package nicolib;
 
 public class NicolibException extends Exception {
         /**
          * 
          */
         private static final long serialVersionUID = -3171710921475666736L;
 
         public NicolibException(){
                 super();
         }
         
         public NicolibException(String message){
                 super(message); 
         }
         
         public NicolibException(String message, Throwable cause){
                 super(message, cause);
         }
 }