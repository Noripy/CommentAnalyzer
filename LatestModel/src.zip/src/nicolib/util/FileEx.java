package nicolib.util;
 
 import java.io.File;
 import java.io.FileInputStream;
 import java.io.FileOutputStream;
 import java.io.IOException;
 import java.nio.channels.FileChannel;
 
 /**
  * ファイル管理ユーティリティクラス
  * @author hal
  *
  */
 public class FileEx {
         
         /**
          * ファイルのコピー
          * @param in
          * @param out
          * @throws IOException
          */
         public static void copyFile(File in, File out) throws IOException {
         FileChannel sourceChannel = new FileInputStream(in).getChannel();
         FileChannel destinationChannel = new FileOutputStream(out).getChannel();
         sourceChannel.transferTo(0, sourceChannel.size(), destinationChannel);
         sourceChannel.close();
         destinationChannel.close();
     }
 
 }