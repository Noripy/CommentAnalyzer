package nicolib.api;
 
 /**
  * Urlなどを対象のIdに変換できなかったときに発生する例外
  * @author hal
  *
  */
 public class UncompatibleIdException extends NicoApiException {
 
         private static final long serialVersionUID = -7396682017591251588L;
 
         public UncompatibleIdException(){
                 super();
         }
         
         public UncompatibleIdException(String message){
                 super(message); 
         }
         
         public UncompatibleIdException(String message, Throwable cause){
                 super(message, cause);
         }
 }