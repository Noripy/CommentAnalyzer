package nicolib.api;
 
 import nicolib.NicolibException;
 
 public class NicoApiException extends NicolibException {
         /**
          * 
          */
         private static final long serialVersionUID = 5853411787433364936L;
 
         public NicoApiException(){
                 super();
         }
         
         public NicoApiException(String message){
                 super(message); 
         }
         
         public NicoApiException(String message, Throwable cause){
                 super(message, cause);
         }
 }